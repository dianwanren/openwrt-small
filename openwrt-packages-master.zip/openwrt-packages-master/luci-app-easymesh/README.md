# luci-app-easymesh
水平有限写了基于kmod-batman-adv+802.11s 有线+无线回程的mesh luci设置插件。

新增ap设置让设置更加方便。

新增KVR设置并添加dawn依赖在ap之间切换延迟明显降低。

插件只对https://github.com/coolsnowwolf/lede lean版openwrt做了测试 其他源码出现问题请自行解决。

写的很烂暂时能用
