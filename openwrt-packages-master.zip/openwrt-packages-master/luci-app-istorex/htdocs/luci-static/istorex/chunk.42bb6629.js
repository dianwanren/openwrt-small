import{_ as r}from"./index.js?v=5b4be379";const e={};function n(_,c){return null}var a=r(e,[["render",n]]);export{a as default};
