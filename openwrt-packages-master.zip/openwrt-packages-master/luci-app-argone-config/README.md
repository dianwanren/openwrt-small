# luci-app-argone-config
argone Theme Config Plugin

You can set the blur and transparency of the login page of argonne theme, and manage the background pictures and videos.

+ 修改为argone ，用于配合luci-app-argone主题，

+ 编译时无需再去删除源码自带的argon主题。
